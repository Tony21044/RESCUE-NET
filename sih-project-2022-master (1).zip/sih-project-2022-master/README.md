Talaash Web Portal
Tracking missing people using aadhar-enabled biometric details.

This is my winning project for SIH 2022.

Tech Stack: HTML, CSS, TailwindCSS, Python, Flask, MongoDB, OpenCV
